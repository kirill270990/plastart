document.querySelector('#catalog').addEventListener('click', e =>{
    document.querySelector('.nav').classList.toggle('block');
  })